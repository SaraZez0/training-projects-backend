<?php
include("init.php");
?>

Hello From Dashboard...

<?php
include("includes/temp/footer.php");
?>
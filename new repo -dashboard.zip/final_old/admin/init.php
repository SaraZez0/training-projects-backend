<?php
include("includes/db/db.php");
include("includes/temp/header.php");
include("includes/temp/navbar.php");
?>